import streamlit as st
import io
import sys
import time
import xml.etree.ElementTree as ET
import pandas as pd
import os
import time
import tkinter as tk
from io import StringIO
import sys
import warnings
warnings.simplefilter("ignore")
#dir_path = os.getcwd()
#dir_path



st.title("My MOVES Runner APP")

run_completed = False
vehicle_directory = "C:\\Users\\Public\\Python envs\\epa\\Scripts\\notebooks\\GRA\\inputs\\Vehicles\\"

def find_files_by_substring(vehicle_type,filename_substring):
    matching_files = []
    for root, dirs, files in os.walk(vehicle_directory +"\\"+vehicle_type):
        for file in files:
            if filename_substring in file:
                file_path = os.path.join(root, file)
                matching_files.append(file_path)
    return matching_files[0]

def createDBImporterFile(vehicle_type,year,age,speed,database_name,agespeed_folder_name,agefilename,speedfilename):
    tree = ET.parse(vehicle_directory+vehicle_type+'/default_importer.xml')
    root = tree.getroot()
    
    year_node = root.find('.//timespan//year')
    year_node.set('key',str(year))
    databaseselection = root.find('.//databaseselection')
    databaseselection.set('databasename',database_name)

    agefilename = find_files_by_substring(vehicle_type,agefilename)
    agedistribution_f =  root.find(".//sourceTypeAgeDistribution//filename")
    agedistribution_f.text = agefilename

    speedfilename = find_files_by_substring(vehicle_type,speedfilename)
    speeddistribution_f =  root.find(".//avgSpeedDistribution//filename")
    speeddistribution_f.text = speedfilename

    fuelsupplyfilename = find_files_by_substring(vehicle_type,str(year)+"fuelsupply")
    fuelsupply_f =  root.find(".//FuelSupply//filename")
    fuelsupply_f.text = fuelsupplyfilename

    fuelformulationfilename = find_files_by_substring(vehicle_type,"fuelformulation")
    fuelformulation_f =  root.find(".//FuelFormulation//filename")
    fuelformulation_f.text = fuelformulationfilename
    
    fuelusagefractionfilename = find_files_by_substring(vehicle_type,str(year)+"fuelusagefraction")
    fuelusagefraction_f =  root.find(".//FuelUsageFraction//filename")
    fuelusagefraction_f.text = fuelusagefractionfilename

    avftfilename = find_files_by_substring(vehicle_type,"avft")
    avft_f =  root.find(".//AVFT//filename")
    avft_f.text = avftfilename

    zonemonthhourfilename = find_files_by_substring(vehicle_type,"zonemonthhour")
    zonemonthhour_f =  root.find(".//zoneMonthHour//filename")
    zonemonthhour_f.text = zonemonthhourfilename

    roadfilename = find_files_by_substring(vehicle_type,str(year)+"road")
    road_f =  root.find(".//roadTypeDistribution//filename")
    road_f.text = roadfilename

    sourcetypepopulationfilename = find_files_by_substring(vehicle_type,str(year)+"sourcetypepopulation")
    sourcetypepopulation_f =  root.find(".//sourceTypeYear//filename")
    sourcetypepopulation_f.text = sourcetypepopulationfilename


    hpmsvtypeyearfilename = find_files_by_substring(vehicle_type,str(year)+"hpmsvtypeyear")
    hpmsvtypeyear_f =  root.find(".//HPMSVtypeYear//filename")
    hpmsvtypeyear_f.text = hpmsvtypeyearfilename

    monthvmtfractionfilename = find_files_by_substring(vehicle_type,"monthvmtfraction")
    monthvmtfraction_f =  root.find(".//monthVMTFraction//filename")
    monthvmtfraction_f.text = monthvmtfractionfilename

    dayvmtfractionfilename = find_files_by_substring(vehicle_type,"dayvmtfraction")
    dayvmtfraction_f =  root.find(".//dayVMTFraction//filename")
    dayvmtfraction_f.text = dayvmtfractionfilename

    hourvmtfractionfilename = find_files_by_substring(vehicle_type,"hourvmtfraction")
    hourvmtfraction_f =  root.find(".//hourVMTFraction//filename")
    hourvmtfraction_f.text = hourvmtfractionfilename

    imcoveragefilename = find_files_by_substring(vehicle_type,str(year)+"imcoverage")
    imcoverage_f =  root.find(".//IMCoverage//filename")
    imcoverage_f.text = imcoveragefilename

    importerfilename = agespeed_folder_name + "dbimporter.xml"
    st.write(importerfilename)
    with open(importerfilename, "wb") as f:
        f.write(ET.tostring(root))
        

    return 

def CreateRunSpec(vehicle_type,year,agespeed_folder_name,inputdatabasename):
    tree = ET.parse(vehicle_directory+vehicle_type+'/default_runspec.xml')
    root = tree.getroot()

    year_node = root.find('.//timespan//year')
    year_node.set('key',str(year))
    scaleinputdatabaseselection = root.find('.//scaleinputdatabase')
    scaleinputdatabaseselection.set('databasename',inputdatabasename)
    outputdatabaseselection = root.find('.//outputdatabase')
    outputdatabasename = inputdatabasename.replace('IPDB','OPDB')
    outputdatabaseselection.set('databasename',outputdatabasename)

    RunSpecfilename = agespeed_folder_name + "Runspec.xml"
    st.write(RunSpecfilename)
    with open(RunSpecfilename, "wb") as f:
        f.write(ET.tostring(root))
    return

def collect_input(year,vehicle_type):
    vehicle_type=vehicle_type.lower();
    vehicle_type=vehicle_type.replace(" ","");
    age = pd.read_excel(vehicle_directory + vehicle_type + '/age.xlsx',sheet_name=None)
    default_ageSTAD = age['SourceTypeAgeDistribution']
    #default_ageAC =  age['AgeCategory']
    #default_ageSUT = age['SourceUseType']
    speed = pd.read_excel(vehicle_directory +vehicle_type + '/speed.xlsx',sheet_name=None)
    default_yearASD = speed['AvgSpeedDistribution']
    fuelsupply = pd.read_excel(vehicle_directory +vehicle_type + '/fuelsupply.xlsx',sheet_name=None)
    default_fuelsupply = fuelsupply['FuelSupply']
    fuelusagefraction = pd.read_excel(vehicle_directory +vehicle_type + '/fuelusagefraction.xlsx',sheet_name=None)
    default_fuelusagefraction = fuelusagefraction['FuelUsageFraction']
    hpmsvtypeyear = pd.read_excel(vehicle_directory +vehicle_type + '/hpmsvtypeyear.xlsx',sheet_name=None)
    default_hpmsvtypeyear = hpmsvtypeyear['HPMSVTypeYear']
    imcoverage = pd.read_excel(vehicle_directory +vehicle_type + '/imcoverage.xlsx',sheet_name=None)
    default_imcoverage = imcoverage['IMCoverage']
    sourcetypepopulation = pd.read_excel(vehicle_directory +vehicle_type + '/sourcetypepopulation.xlsx',sheet_name=None)
    default_sourcetypepopulation = sourcetypepopulation['sourceTypeYear']
    road = pd.read_excel(vehicle_directory +vehicle_type + '/road.xlsx',sheet_name=None)
    default_road = road['roadTypeDistribution']
    start_year = year;
    end_year = year;
    max_age = 30
    max_speed=16
    
    start_time = time.time()
    for year in range(int(start_year),int(end_year)+1):
        year_folder_name = vehicle_directory +vehicle_type+'/'+str(year)+'/'
    
        if not os.path.exists(year_folder_name):
                 os.makedirs(year_folder_name)
    
        temp_year_road= default_road.copy()
        temp_year_road['roadTypeVMTFraction'] = 0.25
        year_road_file_name = year_folder_name+str(year)+'road.xlsx'
        with pd.ExcelWriter(year_road_file_name) as writer:
            temp_year_road.to_excel(writer, sheet_name="roadTypeDistribution", index=False)
            
        temp_year_fuelsupply = default_fuelsupply.copy()
        temp_year_fuelsupply['fuelYearID'] = year
        year_fuel_supply_file_name = year_folder_name+str(year)+'fuelsupply.xlsx'
        with pd.ExcelWriter(year_fuel_supply_file_name) as writer:
            temp_year_fuelsupply.to_excel(writer, sheet_name="FuelSupply", index=False)
    
        temp_year_fuelusagefraction = default_fuelusagefraction.copy()
        temp_year_fuelusagefraction['fuelYearID'] = year
        year_fuelusagefraction_name = year_folder_name+str(year)+'fuelusagefraction.xlsx'
        with pd.ExcelWriter(year_fuelusagefraction_name) as writer:
            temp_year_fuelusagefraction.to_excel(writer, sheet_name="FuelUsageFraction", index=False)
    
        temp_year_hpmsvtypeyear = default_hpmsvtypeyear.copy()
        temp_year_hpmsvtypeyear['yearID'] = year
        year_hpmsvtypeyear_file_name = year_folder_name+str(year)+'hpmsvtypeyear.xlsx'
        with pd.ExcelWriter(year_hpmsvtypeyear_file_name) as writer:
            temp_year_hpmsvtypeyear.to_excel(writer, sheet_name="HPMSVTypeYear", index=False)
    
        temp_year_imcoverage = default_imcoverage.copy()
        temp_year_imcoverage['yearID'] = year
        temp_year_imcoverage['begModelYearID'] = year
        temp_year_imcoverage['endModelYearID'] = year
        year_imcoverage_file_name = year_folder_name+str(year)+'imcoverage.xlsx'
        with pd.ExcelWriter(year_imcoverage_file_name) as writer:
            temp_year_imcoverage.to_excel(writer, sheet_name="IMCoverage", index=False)
    
    
        temp_year_sourcetypepopulation = default_sourcetypepopulation.copy()
        temp_year_sourcetypepopulation['yearID'] = year
        temp_year_sourcetypepopulation['SourceTypePopulation'] = 1
        year_sourcetypepopulation_file_name = year_folder_name+str(year)+'sourcetypepopulation.xlsx'
        with pd.ExcelWriter(year_sourcetypepopulation_file_name) as writer:
            temp_year_sourcetypepopulation.to_excel(writer, sheet_name="sourceTypeYear", index=False)
        
        
        for age in range (0,max_age+1):
            temp_age = default_ageSTAD.copy()
            temp_age['ageFraction'] = 0
            temp_age.loc[temp_age['ageID'] == age, 'ageFraction'] = 1
            temp_age['yearID'] = (year)
            
            for speed in range(1,max_speed+1):
                temp_speed = default_yearASD.copy()
                temp_speed['avgSpeedFraction']=0
                temp_speed.loc[temp_speed['avgSpeedBinID'] == speed, 'avgSpeedFraction'] = 1
                speed_file_name = 'speed'+str(year)+'age'+str(age)+'speed'+str(speed)+'.xlsx'
                #st.write(speed_file_name)
                # st.write(temp_speed)
                age_file_name = 'age'+str(year)+'age'+str(age)+'speed'+str(speed)+'.xlsx'
                #st.write(age_file_name)
                # st.write(temp_age)
                agespeed_folder_name = year_folder_name+'age'+str(age)+'speed'+str(speed)+'/'
                st.write(agespeed_folder_name)
                if not os.path.exists(agespeed_folder_name):
                 os.makedirs(agespeed_folder_name)
                with pd.ExcelWriter(agespeed_folder_name+age_file_name) as writer:
                    temp_age.to_excel(writer, sheet_name="SourceTypeAgeDistribution", index=False)
                    #default_ageAC.to_excel(writer, sheet_name="AgeCategory", index=False)
                    #default_ageSUT.to_excel(writer, sheet_name="SourceUseType", index=False)
                with pd.ExcelWriter(agespeed_folder_name+speed_file_name) as writer:
                    temp_speed.to_excel(writer, sheet_name="AvgSpeedDistribution", index=False)
                inputdatabasename = vehicle_type +str(year)+"age"+str(age)+"speed"+str(speed)+"IPDB"
                createDBImporterFile(vehicle_type,year,age,speed,inputdatabasename,agespeed_folder_name,age_file_name,speed_file_name)
                CreateRunSpec(vehicle_type,year,agespeed_folder_name,inputdatabasename)
                run_completed = True
    
        break
    end_time = time.time()
    execution_time = end_time - start_time
    st.write(f"Execution time: {execution_time} seconds")
    st.write("Generating Files Completed")


with st.form(key='input_form'):
    year = st.text_input('Enter Year')
    vehicle_type = st.text_input('Enter vehicle Type')
    submit_button = st.form_submit_button(label='Generate Files')

if submit_button:
    st.header("Generating all the importer and runspec files...")
    collect_input(year,vehicle_type)

    # Run script 1
output_buffer = io.StringIO()
sys.stdout = output_buffer

while True:
    output = output_buffer.getvalue()
    if output:
        st.code(output)
        output_buffer = io.StringIO()
    else: 
        time.sleep(0.1)
    if run_completed:
        break

sys.stdout = sys.__stdout__