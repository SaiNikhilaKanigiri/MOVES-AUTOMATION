import streamlit as st
import io
import sys
import time
import os
from subprocess import run


def run1(year,vehicle_type):
    dir_path = "C:\\Users\\Public\\Python envs\\epa\\Scripts\\notebooks\\GRA\\inputs\\Vehicles"
    # Set folder paths  
    MOVES_DIR = "C:\\Users\\Public\\EPA\\MOVES4.0"
    VEHICLE_YEAR_FOLDER = os.path.join(dir_path, vehicle_type, year)
    IMPORT_FILE = "dbimporter.xml" 
    RUNSPEC_FILE = "Runspec.xml"
    st.write(VEHICLE_YEAR_FOLDER);
    # Loop through each subfolder
    for folder in os.scandir(VEHICLE_YEAR_FOLDER):
        if folder.is_dir():
            folder_path = os.path.join(VEHICLE_YEAR_FOLDER, folder)
            # Change to subfolder
            os.chdir(MOVES_DIR)
            importer_command = 'ant dbimporter -Dimport="'+os.path.join(folder_path, IMPORT_FILE)+'"'
            runspec_command= 'ant run -Drunspec="'+os.path.join(folder_path, RUNSPEC_FILE)+'"'
            # Call Dbimporter 
            st.write("running importer for "+ folder_path)
            st.write(importer_command)
            importer_result=os.system(importer_command)
            #  print line by line from command prompt
            #for line in os.popen(importer_command):
                #st.write(line)

            st.write("importer completed ")
            
            # Check for success
            if importer_result == 0:
                st.write("importer Success.running runspec for "+ folder_path)
                os.system(runspec_command)
                #for line in os.popen(runspec_command):
                    #st.write(line)
                st.write("runspec completed ")
           # else:
              #  print("Failed")

st.title("My MOVES Runner APP")
run_completed = False




with st.form(key='input_form'):
    year = st.text_input('Enter year')
    vehicle_type = st.text_input('Enter vehicletype')
    submit_button = st.form_submit_button(label='Generate Files')

if submit_button:
    st.header("Running all the importer and runspec files...")
    run1(year,vehicle_type)
    st.write("all importer and runspecs run completed ")
    

    # Run script 1
output_buffer = io.StringIO()
sys.stdout = output_buffer


while True:
    output = output_buffer.getvalue()
    if output:
        st.code(output)
        output_buffer = io.StringIO()
    else: 
        time.sleep(0.1)
    if run_completed:
        break

sys.stdout = sys.__stdout__